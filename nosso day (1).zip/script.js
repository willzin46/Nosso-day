function openEnvelope(el) {
  el.classList.toggle('open');
  if (el.classList.contains('open')) {
    typeWriter();
  }
}

function createHearts() {
  const heartBg = document.getElementById('heartBg');
  for (let i = 0; i < 50; i++) {
    const heart = document.createElement('div');
    heart.classList.add('heart');
    heart.style.left = Math.random() * 100 + 'vw';
    heart.style.animationDuration = 5 + Math.random() * 5 + 's';
    heart.style.opacity = Math.random();
    heart.style.transform = `scale(${Math.random() * 1.5 + 0.5}) rotate(45deg)`;
    heartBg.appendChild(heart);
  }
}
createHearts();

const message = "3 meses ja, eu te amo muito minha princesa, voce a minha razao de viver, obrigado por tudo mais uma vez, serio te amo muito!!";
let index = 0;

function typeWriter() {
  const textElement = document.getElementById("typed-text");
  textElement.innerHTML = "";
  index = 0;
  const interval = setInterval(() => {
    if (index < message.length) {
      textElement.innerHTML += message.charAt(index);
      index++;
    } else {
      clearInterval(interval);
    }
  }, 50);
}